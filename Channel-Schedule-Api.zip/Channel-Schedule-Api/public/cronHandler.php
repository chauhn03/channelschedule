<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$doc = new DOMDocument();
$file = '/home/chauhoan/public_html/channelschedules/Channel-Schedule-Api/public/cron.html';

if ($doc->loadHTMLFile($filename)) {
    $span = $doc->getElementById('spanMessage');
    $stringFormatDate = date('Y-m-d H:i:s');
    $span->nodeValue = $stringFormatDate;
    $doc->save($file);

    echo 'import successfully';
} else {
    return false;
}