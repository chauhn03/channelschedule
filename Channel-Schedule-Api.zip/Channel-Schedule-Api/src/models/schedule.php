<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of schedule
 *
 * @author chau.hoang
 */
class schedule {

    public $Id;
    public $Date;
    public $StartTime;
    public $ChannelId;
    public $Showing;
    public $Programme;

}
